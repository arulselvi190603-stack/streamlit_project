import streamlit as st
import pandas as pd
import plotly.express as px

# 1. Page Configuration
st.set_page_config(page_title="House Price Analytics Dashboard", layout="wide")

# 2. App Title & Description
st.title("🏡 House Price Prediction & Analytics Dashboard")
st.markdown("This interactive dashboard analyzes housing data to uncover insights about pricing, property size, and construction trends.")
st.write("---")

# 3. Load Data
@st.cache_data
def load_data():
    df = pd.read_csv("HousePricePrediction.csv")
    return df

try:
    df = load_data()
    
    # Missing values handles panni, SalePrice target irukara rows-a mattum edukorom
    df_clean = df.dropna(subset=['SalePrice'])
    
    # 4. Sidebar Filter Options
    st.sidebar.header("⚙️ Filter Options")
    zoning_options = st.sidebar.multiselect(
        "Select MSZoning:",
        options=df_clean["MSZoning"].unique(),
        default=df_clean["MSZoning"].unique()
    )
    
    # Filtering data based on selection
    filtered_df = df_clean[df_clean["MSZoning"].isin(zoning_options)]

    # 5. Top Row: Key Metrics (KPIs)
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Houses Analyzed", f"{len(filtered_df)}")
    with col2:
        st.metric("Average Sale Price", f"${filtered_df['SalePrice'].mean():,.2f}")
    with col3:
        st.metric("Avg Lot Area (SqFt)", f"{filtered_df['LotArea'].mean():,.0f}")
    with col4:
        st.metric("Average Year Built", f"{int(filtered_df['YearBuilt'].mean())}")

    st.write("---")

    # 6. Charts Section
    left_column, right_column = st.columns(2)

    with left_column:
        st.subheader("📈 Lot Area vs Sale Price")
        fig_scatter = px.scatter(
            filtered_df, 
            x="LotArea", 
            y="SalePrice", 
            color="MSZoning",
            hover_data=["YearBuilt", "BldgType"],
            title="Price vs Lot Area Size"
        )
        st.plotly_chart(fig_scatter, use_container_width=True)

    with right_column:
        st.subheader("🏢 Average Price by Building Type")
        avg_price_bldg = filtered_df.groupby("BldgType")["SalePrice"].mean().reset_index()
        fig_bar = px.bar(
            avg_price_bldg, 
            x="BldgType", 
            y="SalePrice", 
            color="BldgType",
            title="Avg Sale Price by Building Type"
        )
        st.plotly_chart(fig_bar, use_container_width=True)

    st.write("---")
    
    # 7. Trend Chart (Year Built vs Price)
    st.subheader("⏳ House Prices Based on Construction Year")
    fig_line = px.line(
        filtered_df.groupby("YearBuilt")["SalePrice"].mean().reset_index(),
        x="YearBuilt",
        y="SalePrice",
        title="Average Price Trend over the Years Built"
    )
    st.plotly_chart(fig_line, use_container_width=True)

    # 8. Raw Data Show/Hide
    st.write("---")
    if st.checkbox("Show Raw Dataset"):
        st.subheader("Raw Data Preview")
        st.dataframe(df)

except FileNotFoundError:
    st.error("❌ 'HousePricePrediction.csv' file-a kandupidiika mudiyala. Code irukara same folder-la intha file-aiyum veinga!")
except Exception as e:
    st.error(f"An error occurred: {e}")